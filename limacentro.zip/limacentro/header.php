<!DOCTYPE html>
<html <?php language_attributes(); ?>><head><?php wp_head(); global $current_user; ?></head>
<body <?php body_class(); ?>>
<?php $type = isset($args['type']) ? $args['type'] : ''; ?>

<header class="header-lc">
  <div class="container vertical-align flex-wrap">
    <div class="col-md-4 col-sm-4 col-xs-4">
      <h1 class="header-lc-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>LimaCentro</span></a></h1>
    </div>
    <div class="col-md-1 col-sm-4 col-xs-4">
    </div>
    <nav class="col-md-7 col-sm-4 col-xs-4">
      <ul class="nav header-lc-nav">
        <li>
          <a href="#" class="btn btn-primary btn-lg btn-lc"><ion-icon name="person-outline"></ion-icon> <span class="hidden-sm hidden-xs">Acceder</span></a>
        </li>
      </ul>
    </nav>
  </div>
</header>
