document.addEventListener("DOMContentLoaded", function(event) {
jQuery(function($, undefined){


	//var login = $('#login');
	function loadaccount(section){
		var middle = $('#login_register_form_middle');
		var page = $('#'+section);

		var loadsection = $.ajax({
			type:"GET",
			url:'',
			dataType:'html',
			async:true,
			beforeSend:function(data){

				//console.log(cuenta.preload);

				middle.html('<span class="preloader">Cargando...</span>');
			},
			success:function(data){
				console.log(page);
				middle.html(page[0].innerHTML);
			},
			error: function(error){
				console.log(error);
			}
		}).responseText;

		//return false;
	}

	if(typeof cuenta !== 'undefined' && cuenta.length > 0){
		$.each(cuenta, function(i, val) {
			if(val.active == 1){
				//loadaccount(val.slug);
			}
		});
	}

	/*$(document).on('click', 'a', function(evt){
		evt.preventDefault();
		var sif = true;
		var url = $(this).attr('href');
		var array = url.split('/');
		var section = array.filter(Boolean).pop();
		/*$.each(cuenta, function(i, val) {
			if(section == val.slug){
				console.log(val.slug);
				loadaccount();
			}else{
				sif = false;
			}
		});
		console.log(sif);
		loadaccount(section);
	});	*/

	/*$.ajax({
		type:"GET",
		url:'',
		dataType:'html',
		async:false,
		beforeSend:function(data){ // Are not working with dataType:'jsonp'
			middle.html('Loading...');
		},
		success:function(data){
			middle.html(login[0].innerHTML);
		}
	});*/

	/*$(document).on('submit', 'form',  function(){
       	console.log('sdsd');

		   $.ajax({
			type:"POST",
			//url:'',
			data: $(this).serializeArray(),
			dataType:'json',
			async:false,
			beforeSend:function(data){ // Are not working with dataType:'jsonp'
			},
			success:function(data){
				console.log(data);
			}
		});

		return false;
    });*/

		$(document).on('submit', 'form#lcbusqueda',  function(){
			var $btn = $(this).find('[type=submit]').button('loading');
			$btn.button('reset');
			toastme.default("Espere por favor...");
		});

    $(document).on('submit', 'form#create_product',  function(){
    	var form = $(this);
    	var action = form.attr('action'), method = form.attr('method');
    	var url = cuenta.jxapi || action;

		var data = new FormData();

		var form_data = form.serializeArray();
		$.each(form_data, function (key, input) {
		    data.append(input.name, input.value);
		});

		var num = 0;
		$('input[type="file"]').each(function(){
			var nimgs = $(this).attr('name');
			var fimgs = $(this)[0].files;
        	for (var i = 0; i < fimgs.length; i++) {
        		data.append("imagenes[]", fimgs[i]);
        	}
        num++;
        });

        data.append('apinonce', cuenta.apinonce);

		$.ajax({
		    url: url,
		    method: method,
		    processData: false,
		    contentType: false,
		    data: data,
		    beforeSend: function(){
		    	form.block({message: null,overlayCSS: {background: '#fff',opacity: 0.6}});
		    },
		    success: function (res) {
		        if(res.success == true){
		        	$.dialog({
					    title: 'Alerta',
					    content: res.data.msg || '',
					    onClose: function () {
					        form.get(0).reset();
					        window.location.reload();
					    },
					});
		        }
		        form.unblock();
		    },
		    error: function (e) {
		        console.log(e);
		    }
		});


       	return false;
    });

    function load_products_stats(){

    }

		$(window).on('scroll', function () {
		    var scrollTop = $(window).scrollTop();
				var headerlc = $('.header-lc');
		    if (scrollTop > 10) {
		      headerlc.stop().addClass('hfixed');
		    }else{
					headerlc.stop().removeClass('hfixed');
		    }
		});

		/***************************/

		if($('#map').length > 0){
		var map = L.map('map').setView([-12.0622,-77.0365], 13);

		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
		    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
		}

		/*********************/



		/*******************/

		$('button').on('click', function () {
		 	var $btn = $(this).button('loading')
		 	$btn.button('reset')
		});

		/*$(document).on('click', '#lc_resultados_subir_busqueda',  function(){*/
			const subir_busqueda = $('#lc_resultados_subir_busqueda').magnificPopup({
			  items: {
			    src: jx.current,
			    type: 'ajax'
			  },
				enableEscapeKey: false,
				ajax: {
				 settings: {
					 type: 'POST',
					 data: {
							form: 'subir-busqueda'
					 	}
				 	}
			 	},
				callbacks: {
					parseAjax: function(res) {

						var dt = $(res.data).find('.search-address');
						console.log(dt);
						dt.select2({
						});

						console.log('Ajax content loaded:', res);
					}
				}
			});
		/*});*/


	//var captcha = sliderCaptcha({id: 'captcha'});captcha.reset();

	$(document).on('submit', 'form.busqueda-form',  function(){
		var form = $(this);
		var form_data = form.serializeArray();
		const datos = new FormData();
		var btn = form.find('[type="submit"]');
		$.each(form_data, function (key, input) {
		  datos.append(input.name, input.value);
		});

		datos.append('action', jx.callback);
		datos.append('nonce', jx.nonce);

		const captcha = '';
		const slidercaptcha = $.dialog({title: '',closeIcon: false,
    content: '<div class="slidercaptcha card"><div class="card-header"><span>Arrastre para verificar</span></div><div class="card-body"><div id="captcha"></div></div><script>captcha = sliderCaptcha({id: "captcha", onSuccess: function(){  },onFail: function(){ }, });captcha.reset();</script></div>',
		onContentReady: function () {
			$('#captcha .sliderContainer').bind('DOMNodeInserted DOMNodeRemoved', function(e) {});
		},
		});

		$(document).bind("onSuccessDetect", function (e) {
			if(e.bubbles !== false){

				$.ajax({url: jx.url,method: 'POST',processData: false,contentType: false,data: datos,dataType:'json',async:true,
						beforeSend: function(){
							btn.prop('disabled',true);
						},
						success: function (res) {
								if(res.success !== false){
									slidercaptcha.close();
									subir_busqueda.magnificPopup('close');
									btn.prop('disabled',false);
								}
						},
						error: function (e){
								console.log(e);
						}
				});

			}
		});

		//new Response(datos).text().then(console.log);

		return false;
	});

});
});
