// Ionic Starter App
document.addEventListener("DOMContentLoaded", function (event) {
	(function(t){
		
	t.fn.serializeControls=function(){var e={};return t.each(this.serializeArray(),function(){var i=this.value,r=function e(t,i){if(t.length<1)return i;var r=t[0];"]"==r.slice(-1)&&(r=r.slice(0,-1));var n={};if(1==t.length)n[r]=i;else{t.shift();var a=e(t,i);n[r]=a}return n}(this.name.split("["),i);t.extend(!0,e,r)}),e};	

    const main = document.getElementById("main");
	const loading = document.createElement('ion-loading');
	const ionalert = document.createElement('ion-alert');
	
	const rpage = document.querySelector('ion-router');
	
	const nav = document.querySelector('ion-nav');
	
	
	//let xpage = page.getActive();

	const dnow = new Date().toISOString();
	
	/*rpage.addEventListener('ionRouteDidChange', function () {
		var page = document.querySelector('ion-route');
		page.beforeEnter = isLoggedInGuard(page);
		
		
		page.beforeLeave = isLoggedInGuard(page);
	});*/ 
	
	nav.addEventListener('ionNavDidChange', function () {
		
		console.error(this);
		
		var page = document.querySelector('ion-route');
		
		console.log(page);
		
		//page.beforeEnter = isLoggedInGuard(page);
		 
		//console.log(page.component);
	});
	 
	//page.beforeEnter = isLoggedInGuard();
	
	
	function isLoggedInGuard(e){
		console.log(e.component);
		//var page = document.querySelector('ion-route');
		//console.log( page );
	}
	/*const isLoggedInGuard = async () => {
		
		console.log(this);
	  const isLoggedIn = await UserData.isLoggedIn(); // Replace this with actual login validation

	  if (isLoggedIn) {
		return true;
	  } else {
		return { redirect: '/login' }; // If a user is not logged in, they will be redirected to the /login page
	  }
	}*/

	
	let loadSubmit = function($text,$time='') {
		var form = $('form'); 
		if(form.length > 0){
			$('form').find('input,button,textarea,select,ion-button,ion-select').prop('disabled',true);
		}
		if($text == '' || $text == null){$text = 'Espere...';	}
		if($time !== ''){loading.duration = parseInt($time);}
		loading.message = $text;
		document.body.appendChild(loading);
		if (typeof loading.present === "function") {
		loading.present();
		}else{
			document.body.removeChild(loading);
			return false;
		}
	};
	var close = function(noreset=0){
		var form = $('form');
		if(noreset == 0){
			if(form.length > 0){
				$('form')[0].reset();
				form.find('input,button,textarea,select,ion-button,ion-select').prop('disabled',false);
			}
			var modal = $(document.body).find('ion-modal');
			modal.each(function(index) {
				this.dismiss({'dismissed': true});
			});
		}
		if(noreset > 0){
			form.find('input,button,textarea,select,ion-button,ion-select').prop('disabled',false);
		}
		loading.dismiss();
	};	
	
	/*****/
	
	$(document).on('submit', 'form',function(){
		var form = $(this), data = form.serializeControls(), dataObj = {};
		var btnsubmit = form.find('[type="submit"]');

		let login = parseInt(data.pin);
		
		console.log(login);
		
		if(login > 2){
			//loadSubmit();
			nav.push('page-home', {
					'title': 'Angular',
					'icon': 'angular',
					'description': 'A powerful Javascript framework for building single page apps. Angular is open source, and maintained by Google.',
					'color': '#E63135'
				});
		}
		
		return false;
	});


	customElements.define('page-login', class extends HTMLElement {connectedCallback() {
		var source = document.getElementById("login").innerHTML;
		var template = Handlebars.compile(source);
		var pdata = { title: "Login" };
		var html = template(pdata);
		this.innerHTML = html;
	  }
	});

	customElements.define('page-home', class extends HTMLElement {
	  connectedCallback() {
		//console.log(this.title);
		this.innerHTML = '<ion-header><ion-toolbar><ion-buttons slot="start"><ion-back-button></ion-back-button></ion-button><ion-title>Page two</ion-title></ion-toolbar></ion-header><ion-content><h1>This is the second page<h1></ion-content>';
	  }
	});


    })(jQuery);	  
});	  