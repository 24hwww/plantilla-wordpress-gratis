const db = new localStorageDB('dbapp', localStorage);

const tabla = {user: "tableUser", nclient:"tableClient",pcart:"tpCart",ccart: "tcCart"};

/*	if (!db.tableExists(tableClient)){
		db.createTable(tableClient, ["cid", "company", "cuit","email","first_name","last_name","phone","state","city","address"]);
		db.commit();
	}

	if (!db.tableExists(tpCart)){
		db.createTable(tpCart, ["pid", "pname", "price", "qty", "vid", "vname","amount"]);
		db.commit();
	}
	if (!db.tableExists(tcCart)){
		db.createTable(tcCart, ["cid", "fullname", "email"]);
		db.commit();
	}	
	if (!db.tableExists(tOrder)){
		db.createTable(tOrder, ["ocode","pcount","total","onow","tp", "tc", "tu"]);
		db.commit();
	}
	*/